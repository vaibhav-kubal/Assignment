package com.inventory.assmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
